
"""
Analytics module tests
"""


"""
User management API module
"""

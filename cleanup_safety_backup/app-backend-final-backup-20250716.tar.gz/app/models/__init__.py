
"""TradeSense Data Models"""

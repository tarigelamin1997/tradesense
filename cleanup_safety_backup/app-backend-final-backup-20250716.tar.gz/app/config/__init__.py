
"""TradeSense Configuration"""
